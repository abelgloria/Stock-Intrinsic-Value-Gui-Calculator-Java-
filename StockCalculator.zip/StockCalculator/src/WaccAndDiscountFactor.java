
public class WaccAndDiscountFactor extends CompanyFinancials{
	private double perpetualGrowth;
	private double interestExpense;
	private double longTermDebt;
	private double currentDebt;
	private double incomeBeforeTax;
	private double incomeTaxExpense;
	private double tenYearTreasuryYield;
	private double betaOfStock;
	private double returnOfMarket;
	private double marketCap;
	private double totalDebt;
	
//	Setters and Getters
	public double getPerpetualGrowth() {
		return perpetualGrowth;
	}
	public void setPerpetualGrowth(double perpetualGrowth) {
		this.perpetualGrowth = perpetualGrowth / 100;
	}
	public double getInterestExpense() {
		return interestExpense;
	}
	public void setInterestExpense(double interestExpense) {
		this.interestExpense = interestExpense;
	}
	public double getLongTermDebt() {
		return longTermDebt;
	}
	public void setLongTermDebt(double longTermDebt) {
		this.longTermDebt = longTermDebt;
	}
	public double getCurrentDebt() {
		return currentDebt;
	}
	public void setCurrentDebt(double currentDebt) {
		this.currentDebt = currentDebt;
	}
	public double getIncomeBeforeTax() {
		return incomeBeforeTax;
	}
	public void setIncomeBeforeTax(double incomeBeforeTax) {
		this.incomeBeforeTax = incomeBeforeTax;
	}
	public double getIncomeTaxExpense() {
		return incomeTaxExpense;
	}
	public void setIncomeTaxExpense(double incomeTaxExpense) {
		this.incomeTaxExpense = incomeTaxExpense;
	}
	public double getTenYearTreasuryYield() {
		return tenYearTreasuryYield;
	}
	public void setTenYearTreasuryYield(double tenYearTreasuryYield) {
		this.tenYearTreasuryYield = tenYearTreasuryYield / 100;
	}
	public double getBetaOfStock() {
		return betaOfStock;
	}
	public void setBetaOfStock(double betaOfStock) {
		this.betaOfStock = betaOfStock;
	}
	public double getReturnOfMarket() {
		return returnOfMarket;
	}
	public void setReturnOfMarket(double returnOfMarket) {
		this.returnOfMarket = returnOfMarket / 100;
	}
	public double getMarketCap() {
		return marketCap;
	}
	public void setMarketCap(double marketCap) {
		this.marketCap = marketCap;
	}
	public double getTotalDebt() {
		return totalDebt;
	}
	public void setTotalDebt(double totalDebt) {
		this.totalDebt = totalDebt;
	}
	
//	Method to Calculate WACC
	public Double calculateWACC(double totalDebt,double marketCap, 
			double longTermDebt, double currentDebt, double interestExpense, double incomeTaxExpense,
			double preTaxIncome, double returnOfMarket, double tenYearTreasuryYield, double betaOfStock) {
//		weighted debt calculations
		double denominator = totalDebt + marketCap;
		double weightedDebt = totalDebt/ denominator;
	
//		cost of debt calculations
		denominator = longTermDebt + currentDebt;
		double costOfDebt = interestExpense / denominator;
		
//		calculating 1 - T where T represents tax expense / pre tax income
		double oneMinusT = incomeTaxExpense / incomeBeforeTax;

//		calculating weightedEquity
		denominator = marketCap + totalDebt;
		double weightedEquity = marketCap / denominator;
		
//		calculating the cost of equity
		double rmMinusRf = returnOfMarket - tenYearTreasuryYield;
		double betaOfStockTimesRmMinusRf = betaOfStock * rmMinusRf;
		double costOfEquity = tenYearTreasuryYield + betaOfStockTimesRmMinusRf;
		
//		FINAL WACC CALCULATIONS
		double costOfDebtTimesOneMinusTaxRate = costOfDebt * oneMinusT;
		double weightedDebtTimesCostOfDebtTimesOneMinusTaxRate = weightedDebt * costOfDebtTimesOneMinusTaxRate;
		double weightedEquityTimesCostOfEquity = weightedEquity * costOfEquity;
		
		double requiredReturn = weightedDebtTimesCostOfDebtTimesOneMinusTaxRate + weightedEquityTimesCostOfEquity;
		
		return requiredReturn;
	};
	
	public double calculateTerminalValue(double latestFreeCashFlowEstimate, double requiredReturn, double perpetualGrowth) {
		double onePlusPerpetualGrowth = 1 + perpetualGrowth;
		double requiredReturnMinusPerpetualGrowth = requiredReturn - perpetualGrowth;
		double latestFcfeTimesOnePlusPerpetualGrowth = latestFreeCashFlowEstimate * onePlusPerpetualGrowth;
		double terminalValue = latestFcfeTimesOnePlusPerpetualGrowth / requiredReturnMinusPerpetualGrowth;
		return terminalValue;
	}
	
	public double calculateDiscountFactor(double requiredReturn) {
		double answer = 1 + requiredReturn;
		return answer;
	}
	
}
