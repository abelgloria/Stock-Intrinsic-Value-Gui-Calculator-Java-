import java.util.ArrayList;

import javax.swing.JOptionPane;

public class PresentValueOfFutureCashFlow extends CompanyFinancials{
	
	private double numberOfOutstandingShares;
	

//	Setters and getters
	public double getNumberOfOutstandingShares() {
		return numberOfOutstandingShares;
	}

	public void setNumberOfOutstandingShares(double numberOfOutstandingShares) {
		this.numberOfOutstandingShares = numberOfOutstandingShares;
	}


//	METHODS
	public ArrayList <Double> calculatePresentValueOfFutureCashFlow(ArrayList <Double> freeCashFlowEstimate, double terminalValue, double discountFactor){
		ArrayList <Double> presentValueOfFutureCashFlow = new ArrayList<Double>();
		freeCashFlowEstimate.add(terminalValue);
		
		for(int count = 0; count < NUM_OF_YEARS; count++) {
			int exponentPower = count + 1;
			double discountFactorToThePower = Math.pow(discountFactor, exponentPower);
			
			double presentValue = freeCashFlowEstimate.get(count) / discountFactorToThePower;
			presentValueOfFutureCashFlow.add(presentValue);
		}
		double discountFactorToThePower = Math.pow(discountFactor, 4);
		
		double presentValue = freeCashFlowEstimate.get(4) / discountFactorToThePower;
		presentValueOfFutureCashFlow.add(presentValue);
		
		return presentValueOfFutureCashFlow;
	}
	
	public double calculateIntrinsicValue(ArrayList<Double> presentValueOfFutureCashFlow, double numberOfShares) {
		double sumOfElements = 0;
		double intrinsicValue;
		
		for(int count = 0; count < presentValueOfFutureCashFlow.size(); count++) {
			sumOfElements += presentValueOfFutureCashFlow.get(count);
		}
		
		intrinsicValue = sumOfElements / numberOfShares;
		
		return intrinsicValue;
	}
	
	public void displayIntrinsicValue(double calculateIntrinsicValue,String country) {
		calculateIntrinsicValue = Math.round(calculateIntrinsicValue * 100);
		calculateIntrinsicValue /= 100;
		
		JOptionPane.showMessageDialog(null, "The Intrinsic Values Is $ "+calculateIntrinsicValue+" In "+country+"'s Currency"
				+ "");
	}
}
