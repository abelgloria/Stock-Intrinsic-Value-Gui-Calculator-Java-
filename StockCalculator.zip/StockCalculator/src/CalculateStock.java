import java.util.ArrayList;

import javax.swing.JOptionPane;

public class CalculateStock {
	
	final static int MAX_NUMBER_OF_YEARS = 4;
	public static void main(String[] args) {
		CompanyFinancials companyFinancials = new CompanyFinancials();
		CompanyEstimations companyEstimations = new CompanyEstimations();
		WaccAndDiscountFactor waccAndDiscountFactor = new WaccAndDiscountFactor();
		PresentValueOfFutureCashFlow presentValueOfFutureCashFlow = new PresentValueOfFutureCashFlow();
		
		ArrayList<Double> companyRevenue = new ArrayList<Double>();
		ArrayList<Double> companyNetIncome = new ArrayList<Double>();
		ArrayList<Double> companyFreeCashFlow = new ArrayList<Double>();
		String message;
		String revenueInput;
		String netIncomeInput;
		String companyHomeCountry;
		String freeCashFlowInput;
		int netIncomeYear = 1;
		int revenueYear = 1;
		int freeCashFlowYear = 1;
		double revenue;
		double netIncome;
		double freeCashFlow;
		double perpetualGrowth;
		double interestExpense;
		double longTermDebt;
		double currentDebt;
		double incomeBeforeTax;
		double incomeTaxExpense;
		double tenYearTreasuryYield;
		double betaOfStock;
		double returnOfMarket;
		double marketCap;
		double totalDebt;
		double requiredReturn;
		double ordinaryNumberOfShares;
		
		
//		PROMPTING USER FOR THE COMPANY'S HOME COUNTRY
		try {
			companyHomeCountry = JOptionPane.showInputDialog("Enter the Company's Home Country");
			companyFinancials.setCompanyHomeCountry(companyHomeCountry);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
		}
		
		
//		PROMPTING USER FOR REVENUE
		while(companyRevenue.size() < MAX_NUMBER_OF_YEARS) {
				try {
					message = "Enter Year "+ revenueYear +" Revenue";
					revenueInput = JOptionPane.showInputDialog(message);
					revenue = Double.parseDouble(revenueInput);
					companyRevenue.add(revenue);
					revenueYear++;
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		companyFinancials.setCompanyRevenue(companyRevenue);
		
//		PROMPTING USER FOR NET INCOME
		while(companyNetIncome.size() < MAX_NUMBER_OF_YEARS) {
				try {
					message = "Enter Year "+netIncomeYear+" Net Income";
					netIncomeInput = JOptionPane.showInputDialog(message);
					netIncome = Double.parseDouble(netIncomeInput);
					companyNetIncome.add(netIncome);
					netIncomeYear++;
				} catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
				}
				
			}
		companyFinancials.setCompanyNetIncome(companyNetIncome);
		
//		PROMPTING USER FOR FREE CASH FLOW
		while(companyFreeCashFlow.size() < MAX_NUMBER_OF_YEARS) {
			try {
				message = "Enter Year "+ freeCashFlowYear +" Free Cash Flow";
				freeCashFlowInput = JOptionPane.showInputDialog(message);
				freeCashFlow = Double.parseDouble(freeCashFlowInput);
				companyFreeCashFlow.add(freeCashFlow);
				freeCashFlowYear++;
				
			} catch (Exception e){
				JOptionPane.showMessageDialog(null, "Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
				System.exit(0);
			}
		}
		companyFinancials.setCompanyFreeCashFlow(companyFreeCashFlow);
		
//		CALCULATING AVERAGES AND ESTIMATIONS
		double revenueGrowthAverage = companyFinancials.calculateRevenueGrowthAvverage();
		double profitMarginAverage = companyFinancials.calculateProfitMarginAverage();
		double freeCashFlowDividedByNetIncomeAverage = companyFinancials.calculateFreeCashFlowAverage();
	
		ArrayList<Double> revenueEstimations = companyEstimations.calculateRevenueEstimate(revenueGrowthAverage,companyFinancials.getCompanyRevenue());
		ArrayList<Double> netIncomeEstimations = companyEstimations.calculateNetIncomeEstimates(revenueEstimations, profitMarginAverage);
		ArrayList<Double> freeCashFlowEstimations = companyEstimations.calculateFreeCashFlowEstimate(netIncomeEstimations, freeCashFlowDividedByNetIncomeAverage);
		
		
//		PROMPTING USERS TO CALCULATE WACC
		try {
			message = JOptionPane.showInputDialog("Enter the Country's Latest Perpetual Growth (EX: Enter 1 For 1%)");
			perpetualGrowth = Double.parseDouble(message);
			waccAndDiscountFactor.setPerpetualGrowth(perpetualGrowth);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Interst Expense (Numbers Only)");
			interestExpense = Double.parseDouble(message);
			waccAndDiscountFactor.setInterestExpense(interestExpense);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Long Term Debt (Numbers Only)");
			longTermDebt = Double.parseDouble(message);
			waccAndDiscountFactor.setLongTermDebt(longTermDebt);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Current Debt (Numbers Only)");
			currentDebt = Double.parseDouble(message);
			waccAndDiscountFactor.setCurrentDebt(currentDebt);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Pretax Income (Numbers Only)");
			incomeBeforeTax = Double.parseDouble(message);
			waccAndDiscountFactor.setIncomeBeforeTax(incomeBeforeTax);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Tax Expense (Numbers Only)");
			incomeTaxExpense = Double.parseDouble(message);
			waccAndDiscountFactor.setIncomeTaxExpense(incomeTaxExpense);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Country's 10 Year Treasury Yield (EX: Enter 10 for 10%)");
			tenYearTreasuryYield = Double.parseDouble(message);
			waccAndDiscountFactor.setTenYearTreasuryYield(tenYearTreasuryYield);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Beta of Stock (Numbers Only)");
			betaOfStock = Double.parseDouble(message);
			waccAndDiscountFactor.setBetaOfStock(betaOfStock);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the S&P500's 60 Year Return (EX: Enter 10.42 for 10.42%");
			returnOfMarket = Double.parseDouble(message);
			waccAndDiscountFactor.setReturnOfMarket(returnOfMarket);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Market cap (Numbers Only)");
			marketCap = Double.parseDouble(message);
			waccAndDiscountFactor.setMarketCap(marketCap);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		try {
			message = JOptionPane.showInputDialog("Enter the Company's Latest Total Debt (Numbers Only)");
			totalDebt = Double.parseDouble(message);
			waccAndDiscountFactor.setTotalDebt(totalDebt);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
//		method to calculate wacc or required return
		requiredReturn = waccAndDiscountFactor.calculateWACC(waccAndDiscountFactor.getTotalDebt(),waccAndDiscountFactor.getMarketCap(),
				waccAndDiscountFactor.getLongTermDebt(),waccAndDiscountFactor.getCurrentDebt(),waccAndDiscountFactor.getInterestExpense(),
				waccAndDiscountFactor.getIncomeTaxExpense(),waccAndDiscountFactor.getIncomeBeforeTax(),waccAndDiscountFactor.getReturnOfMarket(),
				waccAndDiscountFactor.getTenYearTreasuryYield(),waccAndDiscountFactor.getBetaOfStock());
		
//		CALCULATING TERMINAL VALUE AND DISCOUNT FACTOR
		double terminalValue = waccAndDiscountFactor.calculateTerminalValue(freeCashFlowEstimations.get(3), requiredReturn,waccAndDiscountFactor.getPerpetualGrowth());
		double discountFactor = waccAndDiscountFactor.calculateDiscountFactor(requiredReturn);
		
//		CALCULATING PRESENT VALUE AND INTRINSIC VALUE
		try {
			message = JOptionPane.showInputDialog("Enter the Number Of a Company's Ordinary Shares Available (Numbers Only)");
			ordinaryNumberOfShares = Double.parseDouble(message);
			presentValueOfFutureCashFlow.setNumberOfOutstandingShares(ordinaryNumberOfShares);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"Invalid Input","Error",JOptionPane.ERROR_MESSAGE);
			System.exit(0);
		}
		
		ArrayList <Double> presentValue = presentValueOfFutureCashFlow.calculatePresentValueOfFutureCashFlow(freeCashFlowEstimations, terminalValue, discountFactor);
		double intrinsicValue = presentValueOfFutureCashFlow.calculateIntrinsicValue(presentValue,presentValueOfFutureCashFlow.getNumberOfOutstandingShares());
		
		presentValueOfFutureCashFlow.displayIntrinsicValue(intrinsicValue,companyFinancials.getCompanyHomeCountry());
	}	
}
