import java.util.ArrayList;

public class CompanyFinancials {
	protected static final double NUM_OF_YEARS = 4; 
	private ArrayList <Double> companyRevenue;
	private ArrayList <Double> companyNetIncome;
	private ArrayList <Double> companyFreeCashFlow;
	private String companyHomeCountry;
	
//	Setters and Getters
	public ArrayList<Double> getCompanyRevenue() {
		return companyRevenue;
	}
	public void setCompanyRevenue(ArrayList<Double> companyRevenue) {
		this.companyRevenue = companyRevenue;
	}
	public ArrayList<Double> getCompanyNetIncome() {
		return companyNetIncome;
	}
	public void setCompanyNetIncome(ArrayList<Double> companyNetIncome) {
		this.companyNetIncome = companyNetIncome;
	}
	public ArrayList<Double> getCompanyFreeCashFlow() {
		return companyFreeCashFlow;
	}
	public void setCompanyFreeCashFlow(ArrayList<Double> companyFreeCashFlow) {
		this.companyFreeCashFlow = companyFreeCashFlow;
	}
	public String getCompanyHomeCountry() {
		return companyHomeCountry;
	}
	public void setCompanyHomeCountry(String companyHomeCountry) {
		this.companyHomeCountry = companyHomeCountry;
	}
//The Following Methods Will Calculate Averages
	public double calculateRevenueGrowthAvverage() {
		double sumOfElements = 0;
		double average;
		ArrayList <Double> revenueGrowthList = new ArrayList<Double>();
		
		for(int count = 1; count < NUM_OF_YEARS; count++) {
			double yearTwo = getCompanyRevenue().get(count);
			double yearOne = getCompanyRevenue().get(count - 1);
			double secondYearMinusYearOne = yearTwo - yearOne;
			
			double revenueGrowth = secondYearMinusYearOne / yearOne;
			revenueGrowthList.add(revenueGrowth);
		}
		
		for(int i = 0; i < NUM_OF_YEARS - 1; i++) {
			sumOfElements += revenueGrowthList.get(i);
		}
		average = sumOfElements / 3;
		return average;
	}
	

	public double calculateProfitMarginAverage() {
		ArrayList <Double> profitMargin = new ArrayList<Double>();
		double sumOfElements = 0;
		double average;
		
		for(int i = 0; i < NUM_OF_YEARS; i++) {
			profitMargin.add(getCompanyNetIncome().get(i) / getCompanyRevenue().get(i)); 
		}
		for(int count = 0; count < NUM_OF_YEARS; count++) {
			sumOfElements += profitMargin.get(count);
		}
		
		average = sumOfElements / NUM_OF_YEARS;
		return average;
	}
	

	public double calculateFreeCashFlowAverage() {
		ArrayList <Double> freeCashFlowDividedByNetIncome = new ArrayList <Double>();
		double average;
		double sumOfElements = 0;
		
		for(int i = 0; i < NUM_OF_YEARS; i++) {
			freeCashFlowDividedByNetIncome.add(getCompanyFreeCashFlow().get(i) / getCompanyNetIncome().get(i));
		}
		for(int count = 0; count < NUM_OF_YEARS; count++) {
			sumOfElements += freeCashFlowDividedByNetIncome.get(count);
		}
		
		average = sumOfElements / NUM_OF_YEARS;
		return average;
	}
}


