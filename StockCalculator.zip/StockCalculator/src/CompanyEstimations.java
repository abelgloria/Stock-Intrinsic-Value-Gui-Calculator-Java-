import java.util.ArrayList;

public class CompanyEstimations extends CompanyFinancials{
	
//	PREDICTIONS
	
	public ArrayList <Double> calculateRevenueEstimate( double revenueGrowthAverage, ArrayList<Double> companyRevenue ){
		double revenueEstimate = 0;
		
		double lastYearOfCompanyRevenue = companyRevenue.get(3);
		
		ArrayList <Double> revenueEstimateList = new ArrayList<Double>();
		for(int i = 0; i < NUM_OF_YEARS; i++) {
			revenueEstimate = lastYearOfCompanyRevenue * revenueGrowthAverage;
			lastYearOfCompanyRevenue += revenueEstimate;
			revenueEstimateList.add(lastYearOfCompanyRevenue);	
		}	
		return revenueEstimateList;
	}
	
	public ArrayList <Double> calculateNetIncomeEstimates(ArrayList <Double> revenueEstimateList, double profitMarginAverage){
		ArrayList <Double> netIncomeEstimateList = new ArrayList<Double>();
		double netIncomeEstimate;
		
		for(int i = 0; i < NUM_OF_YEARS; i++) {
			netIncomeEstimate = revenueEstimateList.get(i) * profitMarginAverage;
			netIncomeEstimateList.add(netIncomeEstimate);
		}
		return netIncomeEstimateList;
	}
	

	public ArrayList <Double> calculateFreeCashFlowEstimate(ArrayList <Double> netIncomeEstimateList, double freeCashFlowAverage){
		ArrayList <Double> freeCashFlowEstimateList = new ArrayList<Double>();
		double freeCashFlowEstimate;
		for(int i = 0; i < NUM_OF_YEARS; i++) {
			freeCashFlowEstimate = netIncomeEstimateList.get(i) * freeCashFlowAverage;
			freeCashFlowEstimateList.add(freeCashFlowEstimate);
		}
		return freeCashFlowEstimateList;
	}
	
}
